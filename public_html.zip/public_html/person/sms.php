<?php

 $curl = curl_init();
        		curl_setopt_array($curl, array(
        			     // CURLOPT_URL => "http://2factor.in/API/V1/9bce6ce9-9c7c-11eb-80ea-0200cd936042/SMS/9914471661/4499/WIN4CLUBS",
        		   CURLOPT_URL => "http://2factor.in/API/V1/6a0befe1-c2c1-11eb-8089-0200cd936042/SMS/9915668595/1111",
        		  CURLOPT_RETURNTRANSFER => true,
        		  CURLOPT_ENCODING => "",
        		  CURLOPT_MAXREDIRS => 10,
        		  CURLOPT_TIMEOUT => 30,
        		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        		  CURLOPT_CUSTOMREQUEST => "GET",
        		  CURLOPT_POSTFIELDS => "",
        		  CURLOPT_HTTPHEADER => array(
        		    "content-type: application/x-www-form-urlencoded"
        		  ),
        		));
        
        		$response = curl_exec($curl);
        		$err = curl_error($curl);
        
        		curl_close($curl);
        
        		if ($err) {
        		  echo "cURL Error #:" . $err;
        		} else {
        		  echo 'success';
        		}

?>