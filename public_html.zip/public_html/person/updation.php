<?php
session_start();
include("connection.php");
error_reporting(0);



$promotiondata = mysqli_query($conn,"SELECT * from promotion where wallet_id >2889");
$addon=2890;
/*
 while($row = mysqli_fetch_array($promotiondata))
 {
     
     $newid= $row['promotion_id']+10000;
    mysqli_query($conn,"update promotion set promotion_id=$newid where promotion_id=$row[promotion_id]");
 }

  while($row = mysqli_fetch_array($promotiondata))
 {
     
    echo "<br>".$row['promotion_id'];
 }
 */

   while($row = mysqli_fetch_array($promotiondata))
 {
     
     $addon=$addon+1;
    mysqli_query($conn,"update promotion set promotion_id=$addon where promotion_id=$row[promotion_id]");
 }
 
?>